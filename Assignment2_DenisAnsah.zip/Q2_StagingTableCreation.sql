/*I am using the AdventureWorks2014_OLTP database*/
USE [AdventureWorks2014_OLTP]
GO

/*I check to see if I havent previously created the staging table*/
IF OBJECT_ID('HumanResources.Employee_Imported', 'U') IS NOT NULL 
  DROP TABLE HumanResources.Employee_Imported; 

/*I create the staging table using characters for the data types for simplicity sake*/
CREATE TABLE [HumanResources].[Employee_Imported](
	[BusinessEntityID] [varchar](50) NOT NULL PRIMARY KEY,
	[NationalIDNumber] [varchar](50) NOT NULL,
	[LoginID] [varchar](256) NOT NULL,
	[OrganizationNode] [varchar](50) NULL,
	[OrganizationLevel]  [varchar](50) NULL,
	[JobTitle] [varchar](50) NOT NULL,
	[BirthDate] [varchar](50) NOT NULL,
	[MaritalStatus] [char](50) NOT NULL,
	[Gender] [char](50) NOT NULL,
	[HireDate] [varchar](50) NOT NULL,
	[SalariedFlag] [varchar](50) NOT NULL,
	[VacationHours] [varchar](50) NOT NULL,
	[SickLeaveHours] [varchar](50) NOT NULL,
	[CurrentFlag] [varchar](50) NOT NULL,
	[rowguid] [varchar](50)  NOT NULL,
	[ModifiedDate] [varchar](50) NOT NULL)
GO
